package com.imooc.exception;

/**
 * Created by 廖师兄
 * 2017-08-03 23:58
 */
public class ResponseBankException extends RuntimeException {
}
