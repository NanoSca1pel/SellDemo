# 文档
1. 课程中的文档都在doc目录里

# 支付相关
1. 授权和支付分开调试，授权用微信官方测试账号，支付用借我的账号，写死openid调试
2. 微信授权 https://www.imooc.com/article/70497
1. 微信支付 https://www.imooc.com/article/31607
1. 扫码登录调试文档 见doc目录下的open.md


# 代码更新记录
#### 2018-6-5
1. 后台图片上传使用又拍云，[又拍云免费体验](https://console.upyun.com/register/?invite=HyTufSjS-)